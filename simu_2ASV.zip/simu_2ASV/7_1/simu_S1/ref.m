function [dpsi,ref] = ref(psi,t,parameters)
c_max=parameters.c_max;
c1_max=parameters.c1_max;
c2_max=parameters.c2_max;
o1=parameters.o1;
psi1=parameters.psi1;
o2=parameters.o2;
psi2=parameters.psi2;
v_max=parameters.v_max;
vareps=parameters.vareps;

% % % straight line
% pd0=[c_max-v_max*t;0];
% pd1=[-v_max;0];
% pd2=[0;0];
% pd3=[0;0];
% pd4=[0;0];
% dpsi=0;%auxiliary

% % % circular curve
% pd0=c_max.*[sin(o1*t+psi1);sin(o2*t+psi2)];
% pd1=c_max.*[o1*cos(o1*t+psi1);o2*cos(o2*t+psi2)];
% pd2=-diag([o1^2;o2^2])*pd0;
% pd3=-diag([o1^2;o2^2])*pd1;
% pd4=diag([o1^4;o2^4])*pd0;
% dpsi=0;%auxiliary

% % % elliptical curve
% pd0=[c1_max*cos(o1*t+psi1); c2_max*sin(o2*t+psi2)];
% pd1=[-c1_max*o1*sin(o1*t+psi1); c2_max*o2*cos(o2*t+psi2)];
% pd2=[-c1_max*o1^2*cos(o1*t+psi1); -c2_max*o2^2*sin(o2*t+psi2)];
% pd3=[c1_max*o1^3*sin(o1*t+psi1); -c2_max*o2^3*cos(o2*t+psi2)];
% pd4=[c1_max*o1^4*cos(o1*t+psi1); c2_max*o2^4*sin(o2*t+psi2)];
% dpsi=0;%auxiliary

% % elliptical varying speed curve
aux0=o1*t+vareps*sin(o1*t)+psi1;
aux1=o1+vareps*o1*cos(o1*t);
aux2=-vareps*o1*o1*sin(o1*t);
aux3=-vareps*o1*o1*o1*cos(o1*t);
aux4=vareps*o1*o1*o1*o1*sin(o1*t);
v1=[-c1_max*sin(aux0);c2_max*cos(aux0)];
v2=[-c1_max*cos(aux0);-c2_max*sin(aux0)];
pd0=-v2;
pd1=aux1*v1;
pd2=aux2*v1+aux1*aux1*v2;
pd3=(aux3-aux1*aux1*aux1)*v1+3*aux1*aux2*v2;
pd4=(aux4-6*aux1*aux1*aux2)*v1+(4*aux1*aux3-aux1*aux1*aux1*aux1+3*aux2*aux2)*v2;
dpsi=0;%auxiliary

% %Lissajous Curve
% Dphi_=Dphi(psi,parameters);
% DDphi_=DDphi(psi,parameters);
% DDDphi_=DDDphi(psi,parameters);
% DDDDphi_=DDDDphi(psi,parameters);
% 
% dpsi=v_max*inv(norm(Dphi_));
% ddpsi=-v_max.*(norm(Dphi_))^(-3).*Dphi_'*DDphi_*dpsi;
% 
% ell=Dphi_;
% Dell=DDphi_*dpsi;
% DDell=DDDphi_*dpsi*dpsi + DDphi_*ddpsi;
% 
% dddpsi=3.*v_max.*norm(ell)^(-5).*(ell'*Dell).*(ell'*Dell)...
%           - v_max.*norm(ell)^(-3).*( Dell'*Dell + ell'*DDell );
% 
% f=Drho(Dphi_);
% g=DDphi_*dpsi;
% h=DDphi_;
% 
% Df=DDrho(Dphi_)*DDphi_*dpsi;
% Dh=DDDphi_*dpsi;
% Dg=kron(dpsi,eye(2))*Dh + h*ddpsi;
% 
% DDf=kron((DDphi_*dpsi)',eye(4))*DDDrho(Dphi_)*DDphi_*dpsi...
%      + DDrho(Dphi_)*( DDDphi_*dpsi*dpsi + DDphi_*ddpsi );
% DDh=DDDDphi_*dpsi*dpsi + DDDphi_*ddpsi;
% DDg=DDh*dpsi + Dh*ddpsi + Dh*ddpsi + h*dddpsi;
% 
% pd0=c_max.*[sin(o1*psi+psi1);sin(o2*psi+psi2)];
% pd1=v_max.*rho(Dphi_);
% pd2=v_max.*Drho(Dphi_)*DDphi_*dpsi;
% pd3=v_max.*( kron(g',eye(2))*Df + f*Dg );
% pd4=v_max.*(kron(Df',eye(2))*kron(eye(2),reshape(eye(2),[4 1]))*Dg...
%                       + kron(g',eye(2))*DDf...
%                       + kron(Dg',eye(2))*Df...
%                       + f*DDg);

ref=[pd0;pd1;pd2;pd3;pd4];

end

function out=Dphi(theta,parameters)
    c_max=parameters.c_max;
    o1=parameters.o1;
    psi1=parameters.psi1;
    o2=parameters.o2;
    psi2=parameters.psi2;
    out=c_max.*[o1*cos(o1*theta+psi1);o2*cos(o2*theta+psi2)];
end

function out=DDphi(theta,parameters)
    c_max=parameters.c_max;
    o1=parameters.o1;
    psi1=parameters.psi1;
    o2=parameters.o2;
    psi2=parameters.psi2;
    out=c_max.*[-o1*o1*sin(o1*theta+psi1);-o2*o2*sin(o2*theta+psi2)];
end

function out=DDDphi(theta,parameters)
    c_max=parameters.c_max;
    o1=parameters.o1;
    psi1=parameters.psi1;
    o2=parameters.o2;
    psi2=parameters.psi2;
    out=c_max.*[-o1*o1*o1*cos(o1*theta+psi1);-o2*o2*o2*cos(o2*theta+psi2)];
end

function out=DDDDphi(theta,parameters)
    c_max=parameters.c_max;
    o1=parameters.o1;
    psi1=parameters.psi1;
    o2=parameters.o2;
    psi2=parameters.psi2;
    out=c_max.*[o1*o1*o1*o1*sin(o1*theta+psi1);o2*o2*o2*o2*sin(o2*theta+psi2)];
end