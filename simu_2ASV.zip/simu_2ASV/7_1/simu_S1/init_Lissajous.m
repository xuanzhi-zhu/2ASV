%stern overhang
clear all
close all
clc

rng('shuffle');
addpath('./myFcns/')

%Froude number<0.4 ===> |dpd|\leq 0.4*sqrt(9.81*L);
Fn=0.4;
L1=1;%effective submerged length of the 1st vessel
L2=1;%effective submerged length of the 2nd vessel
% v_max=Fn*sqrt(9.81*L);

% %ASV1 (p1,v1,q1,o1)\in\reals[2]\x\reals[2]\x\sphere(1)\x\reals
% dp1=R(q1)*v1;
% dv1=-inv(M1)*S*M1*v1*o1 + inv(M1)*drag_v1(v1) + inv(M1)*T1 + inv(M1)*uv;
% dq1=0.5.*S*q1*o1;
% do1=inv(J1)*drag_o1(o1) + inv(J1)*tau1 + inv(J1)*uo;

% %ASV2 (p2,v2,q2,o2)\in\reals[2]\x\reals[2]\x\sphere(1)\x\reals
% dp2=R(q2)*v2;
% dv2=-inv(M2)*S*M2*v2*o2 + inv(M2)*drag_v2(v2) + inv(M2)*T2;
% dq2=0.5.*S*q2*o2;
% do2=inv(J2)*drag_o2(o2) + inv(J2)*tau2;

%%% ref
% % circular curve: pd0=c_max.*[sin(o1*t+psi1);sin(o2*t+psi2)];
% c_max=30;
% o1=1/60;
% psi1=pi/2;
% o2=1/60;
% psi2=0;
% v_max=1;%useless
% psi0=0;%useless
%Lissajous Curve: c_max.*[sin(o1*psi+psi1);sin(o2*psi+psi2)];
c_max=30;
o1=3;
psi1=pi/2;
o2=2;
psi2=0;
v_max=1;
psi0=0;

% Parameters
parameters = struct();
parameters.e1=[1;0];
parameters.e2=[0;1];
parameters.S=[0,-1;1,0];

parameters.l1=0.2;%length from O_B1 to after part of the 1st vessel
parameters.l2=0.3;%length from O_B2 to fore part of the 2st vessel
parameters.l=5;%rope length 5

parameters.Delta_l=0.5;%extended after part of the 1st vessel

parameters.m1=25;
parameters.mx1=-1.5;
parameters.my1=-5.6;
parameters.M1=diag([parameters.m1+abs(parameters.mx1);parameters.m1+abs(parameters.my1)]);
parameters.d_l1=[25;37.5];
parameters.D_l1=diag(parameters.d_l1);
parameters.d_o1=107;%%%
% parameters.d_o1=10.*107;
parameters.d_q1=7;
parameters.J1=4.4;

scaling=1;
parameters.m2=scaling.*25;
parameters.mx2=scaling.*-1.5;
parameters.my2=scaling.*-5.6;
parameters.M2=scaling.*diag([parameters.m2+abs(parameters.mx2);parameters.m2+abs(parameters.my2)]);
parameters.d_l2=scaling.*[25;37.5];
parameters.D_l2=scaling.*diag(parameters.d_l2);
parameters.d_o2=scaling.*107;
parameters.d_q2=scaling.*7;
parameters.J2=scaling.*4.4;

parameters.c_max=c_max;
parameters.o1=o1;
parameters.psi1=psi1;
parameters.o2=o2;
parameters.psi2=psi2;
parameters.v_max=v_max;

parameters.barV=1;
parameters.gamma_p=0.1;
parameters.gamma_v=0.1;
parameters.gamma_ell=0.1;
parameters.gamma_o=0.1;
parameters.k_p=1;
parameters.k_v=1;
parameters.k_ell=1;
parameters.k_o=1;
parameters.gamma_prime=0.5* parameters.k_v*inv(1 + 0.25*inv(parameters.k_p)*parameters.k_v*parameters.k_v);%0<... <k_v*inv(1 + 0.25*inv(k_p)*k_v*k_v)

%check Ass on delta and Froude number, compactness
aux1=Fn*sqrt(9.81*L1);
aux2=Fn*sqrt(9.81*L2);
aux=min(aux1,aux2);

% %normal curve
% flag1=c_max*(o1^2+o2^2)^(0.5)-aux;
%Lissajous Curve
flag1=v_max-aux;


if flag1>=0
    % disp('decrease ref velocities');
    error('decrease ref velocities');
end



e1=parameters.e1;
e2=parameters.e2;
l=parameters.l;
l1=parameters.l1;
l2=parameters.l2;

Delta_l=parameters.Delta_l;

% Initial conditions
ang20=pi;%heading angle of {B2} wrt {I}
R20=ang2rot(ang20);
q20=ang2q(ang20);
q20=q20./norm(q20);
p20=[45;20];
v20=[0;0];
o20=0;

angell0=pi;%heading angle of the rope wrt x_I
Rell0=ang2rot(angell0);
ell0=l.*Rell0*e1;%ell in {I}

ang10=pi;%heading angle of {B1} wrt {I}
R10=ang2rot(ang10);
q10=ang2q(ang10);
q10=q10./norm(q10);
p10=ell0 + (l1+Delta_l).*R10*e1 + l2.*R20*e1 + p20;%%%
v10=[0;0];
o10=0;

%hybrid controller
x0 = [p10;v10;q10;o10; p20;v20;q20;o20];
%ref
[~,ref0]=ref(psi0,0,parameters);
% %check Lyas
% [~,~,~,~,Vcal0]=errs(x0,ref0,parameters);

% Simulation horizon
T = 300;
J = 300;                                                       
                                                                        
% Solver tolerances
AbsTol = 1e-3;
RelTol = AbsTol*AbsTol;
MaxStep = 1e-3;

input_dim=10;%ref dimension

sim('simu_23b.slx')
save data_600s_Lissajous