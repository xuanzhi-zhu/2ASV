% load data_600s_circle
load data_600s_ellipse_disturb
% load data_600s_Lissajous

colors = get(gca,'colororder');
blue=colors(1,:);
red=colors(2,:);
yellow=colors(3,:);
purple=colors(4,:);
green=colors(5,:);
grey=[0.7 0.7 0.7];
black=[0 0 0];

% out=ans;

t=out.tout;
ref=out.ref.signals.values;
x=out.x.signals.values;
% errs=out.errs.signals.values;errs=reshape(errs,[8,length(t)])';
% uT=out.uT.signals.values;
% utau=out.utau.signals.values;

pd0=ref(:,1:2);
pd1=ref(:,3:4);
p1=x(:,1:2);
q1=x(:,5:6);
p2=x(:,8:9);
v2=x(:,10:11);
q2=x(:,12:13);

u_v=out.uv.signals.values;
T2=out.T2.signals.values;

u_v=reshape(u_v,[2,length(t)])';
T_2=reshape(T2,[2,length(t)])';

Delta_l=parameters.Delta_l;

% figure();
Speedy=10;
for i=1:Speedy:length(t)
    %past locations
    plot(pd0(1:i,1),pd0(1:i,2),'o','MarkerSize',2,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(1:i,1),p2(1:i,2),'o','MarkerSize',1,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(1:i,1),p1(1:i,2),'o','MarkerSize',1,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    %current location
    plot(pd0(i,1),pd0(i,2),'o','MarkerSize',5,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(i,1),p2(i,2),'o','MarkerSize',7,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(i,1),p1(i,2),'o','MarkerSize',7,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    %initial location
    plot(pd0(1,1),pd0(1,2),'x','MarkerSize',5,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(1,1),p2(1,2),'x','MarkerSize',7,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(1,1),p1(1,2),'x','MarkerSize',7,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    
    %current xB2 axis (e1) to be expressed in I
    R2=q2rot(q2(i,:));
    xB2_I=5.*R2*e1;
    arrow2_ini=p2(i,1:2)';
    arrow2_end=arrow2_ini + xB2_I;
    plot(linspace(arrow2_ini(1),arrow2_end(1),100),linspace(arrow2_ini(2),arrow2_end(2),100),'LineWidth',2,'Color',blue);hold on;
    %current xB1 axis (e1) to be expressed in I
    R1=q2rot(q1(i,:));
    xB1_I=5.*R1*e1;
    arrow1_ini=p1(i,1:2)';
    arrow1_end=arrow1_ini + xB1_I;
    plot(linspace(arrow1_ini(1),arrow1_end(1),100),linspace(arrow1_ini(2),arrow1_end(2),100),'LineWidth',2,'Color',green);hold on;
    
    %rope
    arrowrope_ini=arrow2_ini + l2.*R2*e1;
    arrowrope_end=arrow1_ini - (l1+Delta_l).*R1*e1;
    plot(linspace(arrowrope_ini(1),arrowrope_end(1),100),linspace(arrowrope_ini(2),arrowrope_end(2),100),'LineWidth',2,'Color',grey);hold on;
    
    
    %u_v expressed in {I}
    arrowrope_end=arrow1_ini - l1.*R1*e1;
    arrow_ini=arrowrope_end;
    u_v_aux=R1*u_v(i,:)';
    arrow_end=arrow_ini + 2.*u_v_aux./norm(u_v_aux);
    plot(linspace(arrow_ini(1),arrow_end(1),100),linspace(arrow_ini(2),arrow_end(2),100),'LineWidth',2,'Color',yellow);hold on;
    
    
    %tension T_2 expressed in {I}
    arrow_ini=arrowrope_ini;
    T_2_aux=R2*T_2(i,:)';
    arrow_end=arrow_ini + 2.*T_2_aux./norm(T_2_aux);
    plot(linspace(arrow_ini(1),arrow_end(1),100),linspace(arrow_ini(2),arrow_end(2),100),'LineWidth',2,'Color',purple);hold on;
    hold off;
    
    halfwidth=0.6;
    %patches 2
    vertices2=[arrowrope_ini';...
                     arrowrope_ini'+(R2*[-2*halfwidth;-halfwidth])';...
                     arrowrope_ini'+(R2*[-2*halfwidth;halfwidth])';...
                     arrowrope_ini'+(R2*[-6*halfwidth;-halfwidth])';...
                     arrowrope_ini'+(R2*[-6*halfwidth;halfwidth])'];
    faces2=[1 2 4 5 3];
    patch('Faces',faces2,'Vertices',vertices2,...
    'EdgeColor',black,'FaceColor','none','LineWidth',2);

    %patches 1
    arrowrope_end=arrow1_ini - l1.*R1*e1;
    vertices1=[arrowrope_end'+(R1*[0;-halfwidth])';...
                     arrowrope_end'+(R1*[0;halfwidth])';...
                     arrowrope_end'+(R1*[4*halfwidth;-halfwidth])';...
                     arrowrope_end'+(R1*[4*halfwidth;halfwidth])';...
                     arrowrope_end'+(R1*[6*halfwidth;0])'];
    faces1=[1 2 4 5 3];
    patch('Faces',faces1,'Vertices',vertices1,...
    'EdgeColor',black,'FaceColor','none','LineWidth',2);
    
    

    % insidePaper=-abs(bo);
    % text(p(i,1)+5,p(i,2)+5,num2str(insidePaper));
    
    grid on;axis equal;
    xlabel('x');ylabel('y');
    % axis([-55 55 -40 40]);%straight line
    axis([-50 100 -100 100]);%curve
    timer=t(i);
    text(49,49,num2str(timer));
    %set(gca,'Ydir','reverse')
    pause(0.0001)
end

% plot(t,sum(T_2.^2,2).^(0.5));%tension along rope