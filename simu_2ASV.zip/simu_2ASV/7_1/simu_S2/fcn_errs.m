function [errs,T2,tension,norm_kappa2] = fcn_errs(x,ref,parameters)
e1=parameters.e1;
e2=parameters.e2;
S=parameters.S;

l1=parameters.l1;
l2=parameters.l2;
l=parameters.l;

Delta_l=parameters.Delta_l;

M1=parameters.M1;
J1=parameters.J1;
Dv_l1=parameters.Dv_l1;
Dv_q1=parameters.Dv_q1;
do_l1=parameters.do_l1;
do_q1=parameters.do_q1;

M2=parameters.M2;
J2=parameters.J2;
Dv_l2=parameters.Dv_l2;
Dv_q2=parameters.Dv_q2;
do_l2=parameters.do_l2;
do_q2=parameters.do_q2;

gamma_p=parameters.gamma_p;
gamma_v=parameters.gamma_v;
gamma_ell=parameters.gamma_ell;
gamma_o=parameters.gamma_o;
k_p=parameters.k_p;
k_v=parameters.k_v;
k_ell=parameters.k_ell;
k_o=parameters.k_o;

pd0=ref(1:2);
pd1=ref(3:4);
pd2=ref(5:6);
pd3=ref(7:8);
pd4=ref(9:10);

p1=x(1:2);
v1=x(3:4);
q1=x(5:6);
o1=x(7);

p2=x(8:9);
v2=x(10:11);
q2=x(12:13);
o2=x(14);

invM1=inv(M1);
invJ1=inv(J1);
R1=q2rot(q1);

invM2=inv(M2);
invJ2=inv(J2);
R2=q2rot(q2);

ell=p1 - (l1+Delta_l).*R1*e1 - p2 - l2.*R2*e1;%%%
ell_prime=R1*(v1 - (l1+Delta_l).*S*e1*o1) - R2*(v2 + l2.*S*e1*o2);%%%

drag_v1=-Dv_l1*v1 - Dv_q1*[(e1'*v1).*norm(e1'*v1); (e2'*v1).*norm(e2'*v1)];
drag_o1=-do_l1*o1 - do_q1*norm(o1)*o1;
drag_v2=-Dv_l2*v2 - Dv_q2*[(e1'*v2).*norm(e1'*v2); (e2'*v2).*norm(e2'*v2)];
drag_o2=-do_l2*o2 - do_q2*norm(o2)*o2;

% Ddrag_v1=-Dv_l1 - 2.*Dv_q1*diag([norm(e1'*v1),norm(e2'*v1)]);
% Ddrag_o1=-do_l1 - 2*do_q1*norm(o1);
Ddrag_v2=-Dv_l2 - 2.*Dv_q2*diag([norm(e1'*v2),norm(e2'*v2)]);
% Ddrag_o2=-do_l2 - 2*do_q2*norm(o2);
%

P=R1*(invM1 + (l1+Delta_l).*l1.*invJ1.*S*e1*e2');%%%
% Q=R1*(invM1 + (l1+Delta_l).*(l1+Delta_l).*invJ1.*S*e1*e2')*R1'...
%  + R2*(invM2 + l2.*l2.*invJ2.*S*e1*e2')*R2';%%%
% chi=R1*S*(v1 - (l1+Delta_l).*S*e1*o1)*o1 - R2*S*(v2 + l2.*S*e1*o2)*o2...
%     - R1*(invM1*S*M1*v1*o1 - invM1*drag_v1 + (l1+Delta_l).*invJ1.*S*e1*drag_o1)...
%     + R2*(invM2*S*M2*v2*o2 - invM2*drag_v2 - l2.*invJ2.*S*e1*drag_o2);%%%
% invP=inv(P);

zp=p2 - pd0;
zv=R2*v2 - pd1;
z=[zp;zv];

% u_v=[5;0];%open loop
% u_v=-5.*zp-0.1.*zv;
% T2_norm=l.*inv(ell'*Q*ell).*(ell_prime'*ell_prime + ell'*chi + ell'*P*u_v);

%angular velocity of the rope
o=l^(-2).*ell'*S'*ell_prime;
%aux
A=inv(l).*R2*invM2*R2';
b=R2*invM2*((M2*S - S*M2)*v2*o2 + drag_v2) - pd2;

A_inv=inv(A);

kappa1=-k_p.*sigma(zp,gamma_p) - k_v.*sigma(zv,gamma_v);
kappa2=A_inv*(kappa1 - b);
Td=inv(l).*norm(kappa2);
if norm(kappa2)<=eps
    error('singularity in control');
end
thetad=l.*rho(kappa2);
%virtual control for the magnitude of T2
T=l^(-2).*ell'*kappa2;

dzp=zv;
dzv=T*A*ell + b;

T2=inv(l).*T.*R2'*ell;
tau2=l2.*e2'*T2;

dv2=inv(M2)*(-S*M2*v2*o2 + drag_v2 + T2);
do2=invJ2*(drag_o2 + tau2);

% dA=inv(l).*R2*(S*invM2 - invM2*S)*R2'*o2;
dA_inv=l.*R2*(S*M2 - M2*S)*R2'*o2;
dkappa1=-k_p.*Dsigma(zp,gamma_p)*dzp - k_v.*Dsigma(zv,gamma_v)*dzv;
db=R2*S*invM2*(M2*S - S*M2)*v2*o2*o2 + R2*invM2*(M2*S - S*M2)*dv2*o2...
   + R2*invM2*(M2*S - S*M2)*v2*do2 + R2*S*invM2*drag_v2*o2 + R2*invM2*Ddrag_v2*dv2 -pd3;
dkappa2=dA_inv*(kappa1 - b) + A_inv*(dkappa1 - db);
thetad_prime=l^(-2).*inv(Td).*thetad'*S'*dkappa2;
% V1_=V1(z,parameters);
DV1_=DV1(z,parameters);
od=-k_ell.*ell'*S*thetad + thetad_prime...
    - inv(gamma_ell).*l^(-2).*Td.*transpose(kron(e2,A*S*ell))*transpose(DV1_);

zo=o-od;

zell=l*l-ell'*thetad;

errs=[zp;zv;zell;zo];

tension=ell'*R2*T2;

norm_kappa2=norm(kappa2);

end
