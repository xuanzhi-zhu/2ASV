function [zp,zv,zell,zo,Vreal] = errs(x,ref,parameters)
e1=parameters.e1;
e2=parameters.e2;
S=parameters.S;

l1=parameters.l1;
l2=parameters.l2;
l=parameters.l;

M1=parameters.M1;
J1=parameters.J1;
D_l1=parameters.D_l1;
d_q1=parameters.d_q1;
d_o1=parameters.d_o1;

M2=parameters.M2;
J2=parameters.J2;
D_l2=parameters.D_l2;
d_q2=parameters.d_q2;
d_o2=parameters.d_o2;

barV=parameters.barV;
gamma_p=parameters.gamma_p;
gamma_v=parameters.gamma_v;
gamma_ell=parameters.gamma_ell;
gamma_o=parameters.gamma_o;
k_p=parameters.k_p;
k_v=parameters.k_v;
k_ell=parameters.k_ell;
k_o=parameters.k_o;


pd0=ref(1:2);
pd1=ref(3:4);
pd2=ref(5:6);
pd3=ref(7:8);
pd4=ref(9:10);

p1=x(1:2);
v1=x(3:4);
q1=x(5:6);
o1=x(7);

p2=x(8:9);
v2=x(10:11);
q2=x(12:13);
o2=x(14);

invM1=inv(M1);
invJ1=inv(J1);
R1=q2rot(q1);

invM2=inv(M2);
invJ2=inv(J2);
R2=q2rot(q2);

ell=p1 - l1.*R1*e1 - p2 - l2.*R2*e1;
ell_prime=R1*(v1 - l1.*S*e1.*o1) - R2*(v2 + l2.*S*e1.*o2);


drag_v2=-D_l2*v2 - d_q2.*(e1'*v2).*norm(e1'*v2).*e1;
drag_o2=-d_o2*o2;


Ddrag_v2=-D_l2 - 2.*d_q2.*norm(e1'*v2).*e1*e1';



zp=p2 - pd0;
zv=R2*v2 - pd1;
z=[zp;zv];

% u_v=[5;0];%open loop
% u_v=-5.*zp-0.1.*zv;
% T2_norm=l.*inv(ell'*Q*ell).*(ell_prime'*ell_prime + ell'*chi + ell'*P*u_v);

%angular velocity of the rope
o=l^(-2).*ell'*S'*ell_prime;
%aux
A=inv(l).*R2*invM2*R2';
b=R2*invM2*((M2*S - S*M2)*v2*o2 + drag_v2) - pd2;

A_inv=inv(A);

kappa1=-k_p.*sigma(zp,gamma_p) - k_v.*sigma(zv,gamma_v);
kappa2=A_inv*(kappa1 - b);
Td=inv(l).*norm(kappa2);
if abs(kappa2)<=eps
    error('singularity in control');
end
thetad=l.*rho(kappa2);
%virtual control for the magnitude of T2
T=l^(-2).*ell'*kappa2;

dzp=zv;
dzv=T*A*ell + b;

T2=inv(l).*T.*R2'*ell;
tau2=l2.*e2'*T2;

dv2=inv(M2)*(-S*M2*v2*o2 + drag_v2 + T2);
do2=invJ2*(drag_o2 + tau2);

dA_inv=l.*R2*(S*M2 - M2*S)*R2'*o2;
dkappa1=-k_p.*Dsigma(zp,gamma_p)*dzp - k_v.*Dsigma(zv,gamma_v)*dzv;
db=R2*S*invM2*(M2*S - S*M2)*v2*o2*o2 + R2*invM2*(M2*S - S*M2)*dv2*o2...
   + R2*invM2*(M2*S - S*M2)*v2*do2 + R2*S*invM2*drag_v2*o2 + R2*invM2*Ddrag_v2*dv2 -pd3;
dkappa2=dA_inv*(kappa1 - b) + A_inv*(dkappa1 - db);
thetad_prime=l^(-2).*inv(Td).*thetad'*S'*dkappa2;
V1_=V1(z,parameters);
DV1_=DV1(z,parameters);
od=-k_ell.*ell'*S*thetad + inv(gamma_ell).*thetad_prime...
    - inv(gamma_ell).*l^(-2).*Td.*transpose(kron(e2,A*S*ell))*Dln(V1_,barV)*transpose(DV1_);

zo=o-od;

zell=(l^2-ell'*thetad)/(l^2);%normalized error

Vreal=ln(V1_,barV)...
    + gamma_ell*(l^2-ell'*thetad)...
    + gamma_o*zo*zo;
end