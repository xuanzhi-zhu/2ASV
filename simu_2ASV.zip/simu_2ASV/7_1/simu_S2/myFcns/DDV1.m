function out=DDV1(z,parameters)
    gamma_p=parameters.gamma_p;
    k_p=parameters.k_p;
    gamma_v=parameters.gamma_v;
    gamma_prime=parameters.gamma_prime;
    
    zp=z(1:2);
    zv=z(3:4);

    sp=sigma(zp,gamma_p);
    sv=sigma(zv,gamma_v);

    Dsp=Dsigma(zp,gamma_p);
    Dsv=Dsigma(zv,gamma_v);

    DDsp=DDsigma(zp,gamma_p);
    DDsv=DDsigma(zv,gamma_v);

    M11=k_p.*Dsp + gamma_prime.*kron(sv',eye(2))*DDsp;
    M12=gamma_prime.*Dsp*Dsv;
    M21=gamma_prime.*Dsv*Dsp;
    M22=gamma_prime.*kron(sp',eye(2))*DDsv + eye(2);

    out=[M11,M12;...
            M21,M22];
end

