function out=DDln(V,barV)
    out=-inv(barV*(1 + V/barV)^2);
    out=0;
end