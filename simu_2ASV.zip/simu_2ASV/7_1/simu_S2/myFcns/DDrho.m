function out=DDrho(x)
    rho_=rho(x);
    Drho_=Drho(x);
    out=-inv(norm(x)).*( reshape(Drho_,[4,1])*rho_' + ( kron(rho_,eye(2)) + kron(eye(2),rho_) )*Drho_ );
end