function out=DDDrho(x)
    rho_=rho(x);
    Drho_=Drho(x);
    DDrho_=DDrho(x);
    
    aux=-DDrho_*norm(x);
    
    K22=[1,0,0,0;...
              0,0,1,0;...
              0,1,0,0;...
              0,0,0,1];
    aux3=kron(K22,eye(2))*kron(eye(2),reshape(eye(2),[4,1]))*Drho_...
              + kron(reshape(eye(2),[4,1]),eye(2))*Drho_;
    
    Daux1=kron(rho_,eye(4))*DDrho_ + kron(eye(2),reshape(Drho_,[4,1]))*Drho_;
    Daux2=kron(Drho_',eye(4))*aux3 + kron(eye(2),kron(rho_,eye(2))+kron(eye(2),rho_))*DDrho_;

    Daux=Daux1 + Daux2;

    out=(norm(x))^(-3).*reshape(aux,[8,1])*x' - (norm(x))^(-1).*Daux;
end
