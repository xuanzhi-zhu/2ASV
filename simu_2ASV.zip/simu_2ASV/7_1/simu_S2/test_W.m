clear all



parameters.k_p=0.6;
parameters.k_v=0.25;
parameters.gamma_p=0.06;
parameters.gamma_v=0.04;
parameters.gamma_prime=0.5* parameters.k_v*inv(1 + 0.25*inv(parameters.k_p)*parameters.k_v*parameters.k_v);%0<... <k_v*inv(1 + 0.25*inv(k_p)*k_v*k_v)


r=1:1:10000;

z=r.*[1/sqrt(2);0;1/sqrt(2);0];

mineig=zeros(size(r));

for i=1:1:numel(r)

mineig(i)=fcn_W(z(:,i),parameters);


end

c=3/2*sqrt(3)*parameters.gamma_prime*parameters.k_p*parameters.gamma_p*parameters.gamma_p*parameters.gamma_v;

plot(r,mineig,'b');hold on
plot(r,c./(r).^3,'r')
set(gca,'YScale','log')
