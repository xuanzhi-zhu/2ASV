% load data_600s_circle
load data_test
% load data_600s_Lissajous

colors = get(gca,'colororder');
blue=colors(1,:);
red=colors(2,:);
yellow=colors(3,:);
purple=colors(4,:);
green=colors(5,:);
grey=[0.7 0.7 0.7];
black=[0 0 0];

% out=ans;

t=out.tout;
ref=out.ref.signals.values;
x=out.x.signals.values;
% errs=out.errs.signals.values;errs=reshape(errs,[8,length(t)])';
% uT=out.uT.signals.values;
% utau=out.utau.signals.values;

pd0=ref(:,1:2);
pd1=ref(:,3:4);
p1=x(:,1:2);
q1=x(:,5:6);
p2=x(:,8:9);
v2=x(:,10:11);
q2=x(:,12:13);


u_v=zeros(length(t),2);
T_2=zeros(length(t),2);
for i=1:1:length(t)
    x_=x(i,:)';
    ref_=ref(i,:)';
    R2=q2rot(q2(i,:));
    zp=p2(i,:)' - pd0(i,:)';
    zv=R2*v2(i,:)' - pd1(i,:)';
    [T_2_,u_v_]=fcn_T2_uv(x_,ref_,parameters);
    T_2(i,:)=T_2_';
    u_v(i,:)=u_v_';
end

Delta_l=parameters.Delta_l;

% figure();
Speedy=100;
for i=1:Speedy:length(t)
    %past locations
    plot(pd0(1:i,1),pd0(1:i,2),'o','MarkerSize',2,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(1:i,1),p2(1:i,2),'o','MarkerSize',1,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(1:i,1),p1(1:i,2),'o','MarkerSize',1,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    %current location
    plot(pd0(i,1),pd0(i,2),'o','MarkerSize',5,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(i,1),p2(i,2),'o','MarkerSize',7,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(i,1),p1(i,2),'o','MarkerSize',7,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    %initial location
    plot(pd0(1,1),pd0(1,2),'x','MarkerSize',5,'MarkerEdgeColor',red,'MarkerFaceColor',red);hold on;
    plot(p2(1,1),p2(1,2),'x','MarkerSize',7,'MarkerEdgeColor',blue,'MarkerFaceColor',blue);hold on;
    plot(p1(1,1),p1(1,2),'x','MarkerSize',7,'MarkerEdgeColor',green,'MarkerFaceColor',green);hold on;
    
    %current xB2 axis (e1) to be expressed in I
    R2=q2rot(q2(i,:));
    xB2_I=5.*R2*e1;
    arrow2_ini=p2(i,1:2)';
    arrow2_end=arrow2_ini + xB2_I;
    plot(linspace(arrow2_ini(1),arrow2_end(1),100),linspace(arrow2_ini(2),arrow2_end(2),100),'LineWidth',2,'Color',blue);hold on;
    %current xB1 axis (e1) to be expressed in I
    R1=q2rot(q1(i,:));
    xB1_I=5.*R1*e1;
    arrow1_ini=p1(i,1:2)';
    arrow1_end=arrow1_ini + xB1_I;
    plot(linspace(arrow1_ini(1),arrow1_end(1),100),linspace(arrow1_ini(2),arrow1_end(2),100),'LineWidth',2,'Color',green);hold on;
    
    %rope
    arrowrope_ini=arrow2_ini + l2.*R2*e1;
    arrowrope_end=arrow1_ini - (l1+Delta_l).*R1*e1;
    plot(linspace(arrowrope_ini(1),arrowrope_end(1),100),linspace(arrowrope_ini(2),arrowrope_end(2),100),'LineWidth',2,'Color',grey);hold on;
    
    
    %u_v expressed in {I}
    arrowrope_end=arrow1_ini - l1.*R1*e1;
    arrow_ini=arrowrope_end;
    u_v_aux=R1*u_v(i,:)';
    arrow_end=arrow_ini + 2.*u_v_aux./norm(u_v_aux);
    plot(linspace(arrow_ini(1),arrow_end(1),100),linspace(arrow_ini(2),arrow_end(2),100),'LineWidth',2,'Color',yellow);hold on;
    
    
    %tension T_2 expressed in {I}
    arrow_ini=arrowrope_ini;
    T_2_aux=R2*T_2(i,:)';
    arrow_end=arrow_ini + 2.*T_2_aux./norm(T_2_aux);
    plot(linspace(arrow_ini(1),arrow_end(1),100),linspace(arrow_ini(2),arrow_end(2),100),'LineWidth',2,'Color',purple);hold on;
    hold off;
    
    halfwidth=0.6;
    %patches 2
    vertices2=[arrowrope_ini';...
                     arrowrope_ini'+(R2*[-2*halfwidth;-halfwidth])';...
                     arrowrope_ini'+(R2*[-2*halfwidth;halfwidth])';...
                     arrowrope_ini'+(R2*[-6*halfwidth;-halfwidth])';...
                     arrowrope_ini'+(R2*[-6*halfwidth;halfwidth])'];
    faces2=[1 2 4 5 3];
    patch('Faces',faces2,'Vertices',vertices2,...
    'EdgeColor',black,'FaceColor','none','LineWidth',2);

    %patches 1
    arrowrope_end=arrow1_ini - l1.*R1*e1;
    vertices1=[arrowrope_end'+(R1*[0;-halfwidth])';...
                     arrowrope_end'+(R1*[0;halfwidth])';...
                     arrowrope_end'+(R1*[4*halfwidth;-halfwidth])';...
                     arrowrope_end'+(R1*[4*halfwidth;halfwidth])';...
                     arrowrope_end'+(R1*[6*halfwidth;0])'];
    faces1=[1 2 4 5 3];
    patch('Faces',faces1,'Vertices',vertices1,...
    'EdgeColor',black,'FaceColor','none','LineWidth',2);
    
    

    % insidePaper=-abs(bo);
    % text(p(i,1)+5,p(i,2)+5,num2str(insidePaper));
    
    grid on;axis equal;
    xlabel('x');ylabel('y');
    % axis([-55 55 -40 40]);%straight line
    axis([-50 100 -100 100]);%curve
    timer=t(i);
    text(49,49,num2str(timer));
    %set(gca,'Ydir','reverse')
    pause(0.0001)
end

function [T2,u_v]=fcn_T2_uv(x,ref,parameters)
e1=parameters.e1;
e2=parameters.e2;
S=parameters.S;

l1=parameters.l1;
l2=parameters.l2;
l=parameters.l;

Delta_l=parameters.Delta_l;

M1=parameters.M1;
J1=parameters.J1;
Dv_l1=parameters.Dv_l1;
Dv_q1=parameters.Dv_q1;
do_l1=parameters.do_l1;
do_q1=parameters.do_q1;

M2=parameters.M2;
J2=parameters.J2;
Dv_l2=parameters.Dv_l2;
Dv_q2=parameters.Dv_q2;
do_l2=parameters.do_l2;
do_q2=parameters.do_q2;

gamma_p=parameters.gamma_p;
gamma_v=parameters.gamma_v;
gamma_ell=parameters.gamma_ell;
gamma_o=parameters.gamma_o;
k_p=parameters.k_p;
k_v=parameters.k_v;
k_ell=parameters.k_ell;
k_o=parameters.k_o;


pd0=ref(1:2);
pd1=ref(3:4);
pd2=ref(5:6);
pd3=ref(7:8);
pd4=ref(9:10);

p1=x(1:2);
v1=x(3:4);
q1=x(5:6);
o1=x(7);

p2=x(8:9);
v2=x(10:11);
q2=x(12:13);
o2=x(14);

invM1=inv(M1);
invJ1=inv(J1);
R1=q2rot(q1);

invM2=inv(M2);
invJ2=inv(J2);
R2=q2rot(q2);

ell=p1 - (l1+Delta_l).*R1*e1 - p2 - l2.*R2*e1;%%%
ell_prime=R1*(v1 - (l1+Delta_l).*S*e1*o1) - R2*(v2 + l2.*S*e1*o2);%%%

drag_v1=-Dv_l1*v1 - Dv_q1*[(e1'*v1).*norm(e1'*v1); (e2'*v1).*norm(e2'*v1)];
drag_o1=-do_l1*o1 - do_q1*norm(o1)*o1;
drag_v2=-Dv_l2*v2 - Dv_q2*[(e1'*v2).*norm(e1'*v2); (e2'*v2).*norm(e2'*v2)];
drag_o2=-do_l2*o2 - do_q2*norm(o2)*o2;

% Ddrag_v1=-Dv_l1 - 2.*Dv_q1*diag([norm(e1'*v1),norm(e2'*v1)]);
% Ddrag_o1=-do_l1 - 2*do_q1*norm(o1);
Ddrag_v2=-Dv_l2 - 2.*Dv_q2*diag([norm(e1'*v2),norm(e2'*v2)]);
Ddrag_o2=-do_l2 - 2*do_q2*norm(o2);

if (abs(v2(1))<=eps) && (abs(v2(2))>=eps)%v2(1)=0 and v2(2)\neq 0
    DDdrag_v2=-2.*kron(eye(2),Dv_q2)*[zeros(4,1), reshape(e2*e2',[4,1])*rho(e2'*v2)];
elseif (abs(v2(1))>=eps) && (abs(v2(2))<=eps)%v2(1)\neq 0 and v2(2)=0
    DDdrag_v2=-2.*kron(eye(2),Dv_q2)*[reshape(e1*e1',[4,1])*rho(e1'*v2), zeros(4,1)];
else
    DDdrag_v2=zeros(4,2);
end

P=R1*(invM1 + (l1+Delta_l).*l1.*invJ1.*S*e1*e2');%%%
Q=R1*(invM1 + (l1+Delta_l).*(l1+Delta_l).*invJ1.*S*e1*e2')*R1'...
 + R2*(invM2 + l2.*l2.*invJ2.*S*e1*e2')*R2';%%%
chi=R1*S*(v1 - (l1+Delta_l).*S*e1*o1)*o1 - R2*S*(v2 + l2.*S*e1*o2)*o2...
    - R1*(invM1*S*M1*v1*o1 - invM1*drag_v1 + (l1+Delta_l).*invJ1.*S*e1*drag_o1)...
    + R2*(invM2*S*M2*v2*o2 - invM2*drag_v2 - l2.*invJ2.*S*e1*drag_o2);%%%
invP=inv(P);

zp=p2 - pd0;
zv=R2*v2 - pd1;
z=[zp;zv];

% u_v=[5;0];%open loop
% u_v=-5.*zp-0.1.*zv;
% T2_norm=l.*inv(ell'*Q*ell).*(ell_prime'*ell_prime + ell'*chi + ell'*P*u_v);

%angular velocity of the rope
o=l^(-2).*ell'*S'*ell_prime;
%aux
A=inv(l).*R2*invM2*R2';
b=R2*invM2*((M2*S - S*M2)*v2*o2 + drag_v2) - pd2;

A_inv=inv(A);

kappa1=-k_p.*sigma(zp,gamma_p) - k_v.*sigma(zv,gamma_v);
kappa2=A_inv*(kappa1 - b);
Td=inv(l).*norm(kappa2);
if norm(kappa2)<=eps
    error('singularity in control');
end
thetad=l.*rho(kappa2);
%virtual control for the magnitude of T2
T=l^(-2).*ell'*kappa2;

dzp=zv;
dzv=T*A*ell + b;

T2=inv(l).*T.*R2'*ell;
tau2=l2.*e2'*T2;

dv2=inv(M2)*(-S*M2*v2*o2 + drag_v2 + T2);
do2=invJ2*(drag_o2 + tau2);

dA=inv(l).*R2*(S*invM2 - invM2*S)*R2'*o2;
dA_inv=l.*R2*(S*M2 - M2*S)*R2'*o2;
dkappa1=-k_p.*Dsigma(zp,gamma_p)*dzp - k_v.*Dsigma(zv,gamma_v)*dzv;
db=R2*S*invM2*(M2*S - S*M2)*v2*o2*o2 + R2*invM2*(M2*S - S*M2)*dv2*o2...
   + R2*invM2*(M2*S - S*M2)*v2*do2 + R2*S*invM2*drag_v2*o2 + R2*invM2*Ddrag_v2*dv2 -pd3;
dkappa2=dA_inv*(kappa1 - b) + A_inv*(dkappa1 - db);
thetad_prime=l^(-2).*inv(Td).*thetad'*S'*dkappa2;
V1_=V1(z,parameters);
DV1_=DV1(z,parameters);
od=-k_ell.*ell'*S*thetad + thetad_prime...
    - inv(gamma_ell).*l^(-2).*Td.*transpose(kron(e2,A*S*ell))*transpose(DV1_);

zo=o-od;

%================
dell=ell_prime;
dthetad=S*thetad*thetad_prime;

dT=l^(-2).*dell'*kappa2 + l^(-2).*ell'*dkappa2;

ddzp=dzv;
ddzv=dA*T*ell + A*dT*ell + A*T*dell + db;


ddv2=-invM2*S*M2*dv2*o2 - invM2*S*M2*v2*do2 + invM2*Ddrag_v2*dv2...
       - invM2*S*R2'*inv(l)*ell*T*o2 + invM2*R2'*inv(l)*dell*T + invM2*R2'*inv(l)*ell*dT;
ddo2=invJ2*Ddrag_o2*do2 - invJ2*l2*e2'*S*R2'*inv(l)*ell*T*o2...
       + invJ2*l2*e2'*R2'*inv(l)*dell*T + invJ2*l2*e2'*R2'*inv(l)*ell*dT;

ddA_inv=-2.*l.*R2*(M2+S*M2*S)*R2'*o2*o2 + l*R2*(S*M2-M2*S)*R2'*do2;
ddkappa1=-k_p.*kron(dzp',eye(2))*DDsigma(zp,gamma_p)*dzp - k_p.*Dsigma(zp,gamma_p)*ddzp...
                 - k_v.*kron(dzv',eye(2))*DDsigma(zv,gamma_v)*dzv - k_v.*Dsigma(zv,gamma_v)*ddzv;
ddb=R2*S*o2*(S*invM2*(M2*S - S*M2)*v2*o2*o2 + invM2*(M2*S - S*M2)*dv2*o2...
                        + invM2*(M2*S - S*M2)*v2*do2 + S*invM2*drag_v2*o2...
                        + invM2*Ddrag_v2*dv2) - pd4...
     + R2*S*invM2*(M2*S - S*M2)*dv2*o2*o2 + 2.*R2*S*invM2*(M2*S - S*M2)*v2*o2*do2...
     + R2*invM2*(M2*S - S*M2)*ddv2*o2 + R2*invM2*(M2*S - S*M2)*dv2*do2...
     + R2*invM2*(M2*S - S*M2)*dv2*do2 + R2*invM2*(M2*S - S*M2)*v2*ddo2...
     + R2*S*invM2*Ddrag_v2*dv2*o2 + R2*S*invM2*drag_v2*do2...
     + R2*invM2*kron(dv2',eye(2))*DDdrag_v2*dv2 + R2*invM2*Ddrag_v2*ddv2;

ddkappa2=ddA_inv*(kappa1 - b) + dA_inv*(dkappa1 - db)...
               + dA_inv*(dkappa1 - db) + A_inv*(ddkappa1 - ddb);
dTd_inv=(-1).*l.*norm(kappa2)^(-3).*kappa2'*dkappa2;
dthetad_prime=l^(-2).*dTd_inv.*thetad'*S'*dkappa2...
                     + l^(-2).*inv(Td).*dthetad'*S'*dkappa2...
                     + l^(-2).*inv(Td).*thetad'*S'*ddkappa2;
%
dTd=inv(l).*inv(norm(kappa2)).*kappa2'*dkappa2;
dDV1=DDV1(z,parameters)*[dzp;dzv];
daux=transpose(kron(e2,A*S*ell))*dDV1 + transpose(kron(e2,(dA*S*ell + A*S*dell)))*DV1_';

%================


dod=-k_ell.*dell'*S*thetad - k_ell.*ell'*S*dthetad...
      + dthetad_prime...
      - inv(gamma_ell).*l^(-2).*dTd.*transpose(kron(e2,A*S*ell))*transpose(DV1_)...
      - inv(gamma_ell).*l^(-2).*Td.*daux;

%virtual control for the direction of T2
tau=-k_o.*zo - inv(gamma_o).*gamma_ell.*ell'*S*thetad...
    - l^(-2).*ell'*S'*chi + l^(-3).*ell'*S'*Q*T*ell...
    + dod;

%input transformation
u_v=invP*( l^(-3).*(ell'*Q*ell).*ell*T + S*ell*tau - l^(-2).*(ell_prime'*ell_prime + ell'*chi)*ell );

%only used for simulation
T2_norm=l.*inv(ell'*Q*ell).*(ell_prime'*ell_prime + ell'*chi + ell'*P*u_v);
T2=inv(l).*T2_norm.*R2'*ell;
end

% plot(t,sum(T_2.^2,2).^(0.5));%tension along rope