function bar_z=fcn_bar_z(zp_0,zv_0,zell_0,zo_0,parameters)
%%%bar_z=\lbar{\alpha}_1\inv \left( \bar{\alpha}_1(|z(0)|)+ 0.5\gamma[\omega]z_{\omega}(0)^2 +\gamma[\ell]|z_{\ell}(0)| \right)

k_p=parameters.k_p;
k_v=parameters.k_v;
gamma_p=parameters.gamma_p;
gamma_v=parameters.gamma_v;
gamma_prime=parameters.gamma_prime;
gamma_o=parameters.gamma_o;
gamma_ell=parameters.gamma_ell;

% %% Parameters
% k_p = 0.72;
% k_v = 1.44;
% gamma_p = 0.09;
% gamma_v = 0.036;
% gamma_prime = 0.4186;

C = norm([zp_0;zv_0]); 
D = 0.5*gamma_o*zo_0*zo_0 + gamma_ell*zell_0;

%% Radius grid

r = linspace(0,10000,100000);

%% Compute lower and upper radial bounds

m = zeros(size(r));
M = zeros(size(r));

for k = 1:length(r)

    m(k) = lowerBound( ...
        r(k), ...
        k_p, ...
        gamma_p, ...
        gamma_v, ...
        gamma_prime);

    M(k) = upperBound( ...
        r(k), ...
        k_p, ...
        gamma_p, ...
        gamma_v, ...
        gamma_prime);
end

%% Example trajectory V(r)

V = zeros(size(r));

for k = 1:length(r)

    a = r(k)/sqrt(2);
    b = r(k)/sqrt(2);

    term1 = k_p*gamma_p * ...
        (sqrt(gamma_p^2 + a^2) - gamma_p);

    qp = gamma_p*a/sqrt(gamma_p^2 + a^2);
    qv = gamma_v*b/sqrt(gamma_v^2 + b^2);

    term2 = gamma_prime*qp*qv;

    term3 = 0.5*b^2;

    V(k) = term1 + term2 + term3;

end

%% Compute alphaUpper(C)+D

alphaUpperC = upperBound( ...
    C, ...
    k_p, ...
    gamma_p, ...
    gamma_v, ...
    gamma_prime);

level = alphaUpperC + D;

fprintf('alphaUpper(C) = %.10f\n',alphaUpperC);
fprintf('level         = alphaUpper(C) + D = %.10f\n',level);

%% Check monotonicity of m(r)

dm = diff(m);

fprintf('\n');
fprintf('Monotonicity check:\n');
fprintf('min(diff(m)) = %e\n',min(dm));

%% Compute alphaLower^{-1}(alphaUpper(C)+D)

if level > max(m)

    error(['Increase the upper limit of r. ', ...
           'Current grid is not large enough.']);

end

R = interp1(m,r,level,'linear');

fprintf('\n');
fprintf('Approximate alphaLower^{-1}(alphaUpper(C)+D)\n');
fprintf('R = %.10f\n',R);

bar_z=R;

% %% Plot
% 
% figure;
% hold on;
% 
% plot(r,m,'b','LineWidth',2);
% plot(r,M,'r--','LineWidth',2);
% plot(r,V,'k','LineWidth',2);
% 
% yline(alphaUpperC,'c--','LineWidth',1.5);
% yline(level,'k:','LineWidth',1.5);
% 
% xline(C,'g--','LineWidth',1.5);
% xline(R,'m-.','LineWidth',1.5);
% 
% xlabel('r');
% ylabel('Value');
% 
% legend( ...
%     'm(r)=\alpha_L(r)', ...
%     'M(r)=\alpha_U(r)', ...
%     'Sample V_1', ...
%     '\alpha_U(C)', ...
%     '\alpha_U(C)+D', ...
%     'C', ...
%     '\bar{z}=\alpha_L^{-1}(\alpha_U(C)+D)', ...
%     'Location','northwest');
% 
% title('Approximation of \alpha_L^{-1}(\alpha_U(C)+D)');
% 
% grid on;
% box on;

%% =====================================================================
%% FUNCTIONS
%% =====================================================================

function val = lowerBound(r,kp,gammaP,gammaV,gammaPrime)

    if r <= 0
        val = 0;
        return;
    end

    obj = @(phi) ...
        Vrad(phi,r,kp,gammaP,gammaV,gammaPrime,-1);

    [~,val] = fminbnd(obj,0,pi/2);

end

function val = upperBound(r,kp,gammaP,gammaV,gammaPrime)

    if r <= 0
        val = 0;
        return;
    end

    obj = @(phi) ...
        -Vrad(phi,r,kp,gammaP,gammaV,gammaPrime,+1);

    [~,fmin] = fminbnd(obj,0,pi/2);

    val = -fmin;

end

function V = Vrad(phi,r,kp,gammaP,gammaV,gammaPrime,sgn)

    a = r*cos(phi);
    b = r*sin(phi);

    term1 = kp*gammaP * ...
        (sqrt(gammaP^2 + a.^2) - gammaP);

    qp = gammaP*a ./ ...
        sqrt(gammaP^2 + a.^2);

    qv = gammaV*b ./ ...
        sqrt(gammaV^2 + b.^2);

    crossTerm = sgn * gammaPrime .* qp .* qv;

    term3 = 0.5*b.^2;

    V = term1 + crossTerm + term3;

end

end
