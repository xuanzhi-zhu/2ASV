clear all
close all


load data_7_3_1
% V=out.V.signals.values;
% errs_S1=out.errs.signals.values;
% % ref=out.ref.signals.values;
tout_S1=out.tout;
% uv_S1=out.uv.signals.values;
% x=out.x.signals.values;
norm_pd1=out.norm_pd1.signals.values;

% [dimx,dimy,dimz]=size(errs_S1);
% errs_S1=reshape(errs_S1,[dimx dimz]);
% uv_S1=reshape(uv_S1,[2 dimz]);

% zp_S1=errs_S1(1:2,:);
% zv_S1=errs_S1(3:4,:);
% zell_S1=errs_S1(5,:);
% zo_S1=errs_S1(6,:);
% 
% norm_zp_S1=(sum(zp_S1.^2,1)).^(1/2);
% norm_zv_S1=(sum(zv_S1.^2,1)).^(1/2);
% norm_zell_S1=abs(zell_S1);
% norm_zo_S1=abs(zo_S1);
% norm_uv_S1=(sum(uv_S1.^2,1)).^(1/2);

clear out



layout = [1;1;1;1]*ones(1,8);
% h=create_axis(layout,15,...
%     'innerymargin',0.015,...
%     'botmargin',.13,...
%     'innerxmargin',0.06,...
%     'leftmargin',0.05);
h=create_axis(layout,25,...
    'innerymargin',0.1,...
    'botmargin',0,...
    'innerxmargin',0.015,...
    'leftmargin',0.1);
colors = get(gca,'colororder');
% blue=colors(1,:);
blue=1/256.*[108 142 191];
red=1/256.*[185 84 80];
yellow=1/256.*[215 154 2];
purple=1/256.*[151 115 166];
% green=colors(5,:);
green=1/256.*[129 179 101];
grey=[0.7 0.7 0.7];
black=[0 0 0];

lineWidth = 2;
markerSize = 8;

vertical_Line=linspace(10,5,10);

h2=plot(tout_S1,norm_pd1,'-','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h3=plot(tout_S2,norm_uv_S2,'--','Color',green,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h4=plot(tout_S3,norm_uv_S3,'-.','Color',0.8.*grey,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h5=plot(tout_S4,norm_uv_S4,':','Color',yellow,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
h1=plot(T_switch.*ones(numel(vertical_Line)),vertical_Line,'-','Color',grey,'LineWidth',5*lineWidth,'MarkerSize',markerSize);

% plot(tout,norm_zv,'-.','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout,norm_zell,'-.','Color',green,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout,norm_zo,':','Color',yellow,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout,abs(V),'-','Color',grey,'LineWidth',2*lineWidth,'MarkerSize',markerSize);hold off

grid on
set(gca, 'YScale', 'linear')

% yh=ylabel('$[N]$','fontsize',12)
xlim([0,200])
ylim([0,3.5])

% Adjust position - negative values move left, positive move right
% % Format: [x, y, z] in normalized units
% set(yh, 'Units', 'normalized');
% currentPos = get(yh, 'Position');
% set(yh, 'Position', [currentPos(1)-0.06, currentPos(2), currentPos(3)]);  % Move left

% 
% leg=legend([h2], {'$|p_d^{(1)}(t)|$'},'fontsize',12);
% legend('boxoff')
% leg.Orientation='vertical';
% set(leg,...
%     'Location','best')
% pos = leg.Position;
% set(leg,...
%     'Position',pos+[-0.1 0.1 0 0.1])

% Reorder children 
ax = gca;
ax.Children = [h2;h1];




% text(-95+380,5*1e9,'$b_1^v=b_2^v=0\,\leftarrow$')
% text(105+500,5*1e9,'$\rightarrow\, b_1^v,b_2^v\neq 0$')



% yticks = ([10^(-15) 10^(-10) 10^(-5) 10^(0)]);
% yticklabels({'0','10^{-10}','10^{-5}','10^{0}'})

xlabel('$t\,[s]$','fontsize',12)
ax = gca; % current axes
ax.FontSize = 12;
% ylabel('$$','fontsize',12)

% yticks = ([10^(-15) 10^(-10) 10^(-5) 10^(0)]);
% yticklabels({'0','10^{-10}','10^{-5}','10^{0}'})

xh=xlabel('$t\,[s]$','fontsize',12)
yh=ylabel('$|p_d^{(1)}(t)|\,[m/s]$','fontsize',12)
ax = gca; % current axes
ax.FontSize = 12;

% Adjust position - negative values move left, positive move right
% Format: [x, y, z] in normalized units
set(xh, 'Units', 'normalized');
currentPos = get(xh, 'Position');
set(xh, 'Position', [currentPos(1), currentPos(2)-0.05, currentPos(3)]);  % Move down

set(yh, 'Units', 'normalized');
currentPos = get(yh, 'Position');
set(yh, 'Position', [currentPos(1)-0.02, currentPos(2), currentPos(3)]);  % Move left
ax = gca; % current axes
ax.FontSize = 12;



% % create a new pair of axes inside current figure
% h=axes('position',[.20 .60 .3 .25])
% 
% box on % put box around new pair of axes
% 
% 
% vertical_Line=linspace(0,2*1e9,10);
% % plot(tout_nominal,norm_zp_nominal,'--','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h1=plot(T_switch.*ones(numel(vertical_Line)),vertical_Line,'-','Color',grey,'LineWidth',5*lineWidth,'MarkerSize',markerSize);hold on
% h2=plot(tout_S1,norm_uv_S1,'-','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h3=plot(tout_S2,norm_uv_S2,'--','Color',green,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h4=plot(tout_S3,norm_uv_S3,'-.','Color',0.8.*grey,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on
% h5=plot(tout_S4,norm_uv_S4,':','Color',yellow,'LineWidth',lineWidth,'MarkerSize',markerSize);
% 
% ax = gca;
% ax.Children = [h2;h5;h4;h3;h1];
% 
% % plot(tout,norm_zv,'-.','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% % plot(tout,norm_zell,'-.','Color',green,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% % plot(tout,norm_zo,':','Color',yellow,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% % plot(tout,abs(V),'-','Color',grey,'LineWidth',2*lineWidth,'MarkerSize',markerSize);hold off
% 
% xticks(h,[0 1200])
% % xticks = ([500 600]);
% 
% % xticklabels({'500','600'})
% grid on
% set(gca, 'YScale', 'linear')
% % axis tight
% 
% 
% xlim([0,1200])
% ylim([0,350])
% % create a new pair of axes inside current figure
% h=axes('position',[.25 .60 .25 .25])
% box on % put box around new pair of axes
% 
% plot(T_switch.*ones(numel(vertical_Line)),vertical_Line,'-','Color',grey,'LineWidth',5*lineWidth,'MarkerSize',markerSize);hold on
% plot(tout_nominal,uv_nominal(1,:),'--','Color',blue,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout_nominal,uv_nominal(2,:),'-.','Color',yellow,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout_disturb,uv_disturb(1,:),'-','Color',green,'LineWidth',lineWidth,'MarkerSize',markerSize);hold on;
% plot(tout_disturb,uv_disturb(2,:),':','Color',purple,'LineWidth',lineWidth,'MarkerSize',markerSize);
% 
% 
% xticks(h,[0 1])
% % xticks = ([500 600]);
% 
% % xticklabels({'500','600'})
% grid on
% set(gca, 'YScale', 'linear')
% % axis tight
% 
% 
% xlim([0,1])
% ylim([-75,420])


matlabfrag2('speed')