function out=fcn_varo(input,parameters)

    ub_pd1=parameters.ub_pd1;

    syms s real positive
    
    phi=fcn_phi(s,parameters);
    
    %numerically solve the pre-image of phi
    aux=fcn_ln_inv(input,parameters);
    phi_inv=vpasolve(aux-phi,[eps,10000]);
    lb_alpha_inv=fcn_alpha(aux,phi_inv,parameters);
    
    out=ub_pd1 + lb_alpha_inv;
end

function out=fcn_alpha(input,phi_inv,parameters)
    out=sqrt(input/fcn_lambda(phi_inv,parameters));
end

function out=fcn_phi(in,parameters)
    s=in;

    out=fcn_lambda(s,parameters)*s*s;
end

function out=fcn_lambda(in,parameters)

    gamma_p=parameters.gamma_p;
    k_p=parameters.k_p;
    gamma_prime=parameters.gamma_prime;
    
    s=in;

    aux1=gamma_p*k_p/(4*sqrt(gamma_p^2+s^2)) + 1/4;
    aux2=(k_p-gamma_prime^2)*gamma_p/(4*sqrt(gamma_p^2+s^2));
    out=aux1 - sqrt(aux1^2-aux2);
end

function out=fcn_ln_inv(in,parameters)
    barV=parameters.barV;

    out=barV* ( exp(in/barV) - 1 );
end