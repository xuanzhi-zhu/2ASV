function out=V1(z,parameters)
    gamma_p=parameters.gamma_p;
    k_p=parameters.k_p;
    gamma_v=parameters.gamma_v;
    gamma_prime=parameters.gamma_prime;

    zp=z(1:2);
    zv=z(3:4);

    out=k_p*gamma_p*(sqrt(gamma_p*gamma_p + zp'*zp) - gamma_p)...
        + gamma_prime.*transpose(sigma(zp,gamma_p))*sigma(zv,gamma_v)...
        + 0.5.*zv'*zv;
end

