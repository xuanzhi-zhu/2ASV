function out=Dln(V,barV)
    out=inv(1 + V/barV);
    out=1;
end