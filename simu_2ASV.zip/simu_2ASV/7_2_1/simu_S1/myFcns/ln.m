function out=ln(V,barV)
    out=barV*log(1 + V/barV);
    out=V;
end