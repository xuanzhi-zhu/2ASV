function out=sigma(s,gamma)
    out= gamma./sqrt(gamma*gamma + s'*s).*s;
end