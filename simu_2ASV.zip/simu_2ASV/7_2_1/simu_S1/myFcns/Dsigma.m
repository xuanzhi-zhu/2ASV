function out=Dsigma(s,gamma)
    sigma_s=sigma(s,gamma);
    out= gamma./sqrt(gamma*gamma + s'*s)...
        .* (eye(2)-gamma^(-2).*sigma_s*sigma_s');
end
