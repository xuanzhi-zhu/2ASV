function out=proj2(mu,htheta,parameters)
w2_bar=parameters.w2_bar;

out=mu-eta1(htheta,parameters)*eta2(mu,htheta,parameters)*inv(w2_bar).*htheta;

end

function out=eta1(s,parameters)
n_w=parameters.n_w;
w2_bar=parameters.w2_bar;
hw2_bar=parameters.hw2_bar;

dist=max(0,norm(s)-w2_bar);

out=(hw2_bar-w2_bar)^(-n_w-1)*dist^(n_w+1);
end


function out=eta2(t,s,parameters)
w2_bar=parameters.w2_bar;
delta2=parameters.delta2;

aux=inv(w2_bar)*t'*s;
out=aux+ (aux^2+delta2^2)^(0.5);
out=0.5*out;
end
