function out=DV1(z,parameters)
    gamma_p=parameters.gamma_p;
    k_p=parameters.k_p;
    gamma_v=parameters.gamma_v;
    gamma_prime=parameters.gamma_prime;
    
    zp=z(1:2);
    zv=z(3:4);

    out=[k_p.*transpose(sigma(zp,gamma_p)) + gamma_prime.*transpose(sigma(zv,gamma_v))*Dsigma(zp,gamma_p),...
        gamma_prime.*transpose(sigma(zp,gamma_p))*Dsigma(zv,gamma_v) + zv'];
end

