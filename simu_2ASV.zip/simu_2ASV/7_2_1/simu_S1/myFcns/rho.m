function out=rho(x)
    out=x./norm(x);
end
