function out=DDsigma(s,gamma)
    sigma_s=sigma(s,gamma);
    Dsigma_s=Dsigma(s,gamma);
    out= - inv(gamma)./sqrt(gamma*gamma + s'*s)...
        .* (reshape(Dsigma_s,[4,1])*sigma_s' + (kron(sigma_s,eye(2))+kron(eye(2),sigma_s))*Dsigma_s);
end
