function out=proj1(mu,htheta,parameters)
w1_bar=parameters.w1_bar;

out=mu-eta1(htheta,parameters)*eta2(mu,htheta,parameters)*inv(w1_bar).*htheta;

end

function out=eta1(s,parameters)
n_w=parameters.n_w;
w1_bar=parameters.w1_bar;
hw1_bar=parameters.hw1_bar;

dist=max(0,norm(s)-w1_bar);

out=(hw1_bar-w1_bar)^(-n_w-1)*dist^(n_w+1);
end


function out=eta2(t,s,parameters)
w1_bar=parameters.w1_bar;
delta1=parameters.delta1;

aux=inv(w1_bar)*t'*s;
out=aux+ (aux^2+delta1^2)^(0.5);
out=0.5*out;
end
