function out=Drho(x)
    out=inv(norm(x)).*(eye(2)-rho(x)*rho(x)');
end