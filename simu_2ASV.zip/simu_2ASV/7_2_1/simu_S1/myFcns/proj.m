function out=proj(mu,htheta,parameters)
w_bar=parameters.w_bar;

out=mu-eta1(htheta,parameters)*eta2(mu,htheta,parameters)*inv(w_bar).*htheta;
end

function out=eta1(s,parameters)
n_w=parameters.n_w;
w_bar=parameters.w_bar;
hw_bar=parameters.hw_bar;

dist=max(0,norm(s)-w_bar);

out=(hw_bar-w_bar)^(-n_w-1)*dist^(n_w+1);
end


function out=eta2(t,s,parameters)
w_bar=parameters.w_bar;
delta=parameters.delta;

aux=inv(w_bar)*t'*s;
out=aux+ (aux^2+delta^2)^(0.5);
out=0.5*out;
end
