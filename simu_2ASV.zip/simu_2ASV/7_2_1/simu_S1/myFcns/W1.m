function out=W1(z,parameters)
    gamma_p=parameters.gamma_p;
    k_p=parameters.k_p;
    gamma_v=parameters.gamma_v;
    k_v=parameters.k_v;
    gamma_prime=parameters.gamma_prime;

    zp=z(1:2);
    zv=z(3:4);
    
    Dsp=Dsigma(zp,gamma_p);
    Dsv=Dsigma(zv,gamma_v);

    P1=gamma_prime.*k_p.*gamma_p^2.*inv(gamma_p^2+zp'*zp).*Dsv;
    P2=gamma_prime.*k_v.*gamma_p.*gamma_v.*inv(sqrt( (gamma_p^2+zp'*zp).*(gamma_v^2+zv'*zv) )).*Dsv;
    P3=k_v.*gamma_v.*inv(sqrt( gamma_v^2+zv'*zv )).*eye(2)...
       - gamma_prime.*gamma_v.*inv(sqrt( gamma_v^2+zv'*zv )).*Dsp;

    P=[P1,0.5.*P2;...
         0.5.*P2,P3];

    out=-z'*P*z;
end

