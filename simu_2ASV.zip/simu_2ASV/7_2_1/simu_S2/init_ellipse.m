%stern overhang
clear all
close all
clc

rng('shuffle');
addpath('./myFcns/')

%Froude number<0.4 ===> |dpd|\leq 0.4*sqrt(9.81*L);
Fn=0.4;
L1=1;%effective submerged length of the 1st vessel
L2=1;%effective submerged length of the 2nd vessel
% v_max=Fn*sqrt(9.81*L);

% %ASV1 (p1,v1,q1,o1)\in\reals[2]\x\reals[2]\x\sphere(1)\x\reals
% dp1=R(q1)*v1;
% dv1=-inv(M1)*S*M1*v1*o1 + inv(M1)*drag_v1(v1) + inv(M1)*T1 + inv(M1)*uv;
% dq1=0.5.*S*q1*o1;
% do1=inv(J1)*drag_o1(o1) + inv(J1)*tau1 + inv(J1)*uo;

% %ASV2 (p2,v2,q2,o2)\in\reals[2]\x\reals[2]\x\sphere(1)\x\reals
% dp2=R(q2)*v2;
% dv2=-inv(M2)*S*M2*v2*o2 + inv(M2)*drag_v2(v2) + inv(M2)*T2;
% dq2=0.5.*S*q2*o2;
% do2=inv(J2)*drag_o2(o2) + inv(J2)*tau2;

%%% ref
% % circular curve: pd0=c_max.*[sin(o1*t+psi1);sin(o2*t+psi2)];
% c_max=30;
% o1=1/60;
% psi1=pi/2;
% o2=1/60;
% psi2=0;
% v_max=1;%useless
% psi0=0;%useless

% % elliptical curve: pd0=[c1_max*cos(o1*t+psi1);  c2_max*sin(o2*t+psi2)];
% c_max=0;%useless
% c1_max=30;
% c2_max=40;
% o1=1/20;
% psi1=pi/6;
% o2=o1;
% psi2=psi1;
% v_max=1;%useless
% psi0=0;%useless

% elliptical varying speed curve: pd0=[c1_max*cos(o1*t+0.5*sin(o1*t)+psi1);  c2_max*sin(o2*t+0.5*sin(o2*t)+psi2)];
c_max=0;%useless
c1_max=30;
c2_max=40;
o1=1/15;%%1/10
psi1=pi/6;
o2=o1;
psi2=psi1;
v_max=1;%useless
psi0=0;%useless
vareps=0.2;

%Ass 2 on reference
lb_pd2=(1-vareps)^2*o1*o1*min(c1_max,c2_max)

ub_pd1=(1+vareps)*o1*max(c1_max,c2_max)
ub_pd2=(1+3*vareps+vareps*vareps)*o1*o1*max(c1_max,c2_max)

% %Lissajous Curve: c_max.*[sin(o1*psi+psi1);sin(o2*psi+psi2)];
% c_max=30;
% o1=3;
% psi1=pi/2;
% o2=2;
% psi2=0;
% v_max=1;
% psi0=0;


% Parameters
parameters = struct();
parameters.e1=[1;0];
parameters.e2=[0;1];
parameters.S=[0,-1;1,0];

parameters.lb_pd2=lb_pd2;
parameters.ub_pd1=ub_pd1;
parameters.ub_pd2=ub_pd2;

% parameters.ub_pd1=ub_pd1;

% parameters.l1=0.39;%length from O_B1 to after part of the 1st vessel
% parameters.l2=0.4;%length from O_B2 to fore part of the 2st vessel
% parameters.l=3;%rope length
parameters.l1=0.3;%length from O_B1 to after part of the 1st vessel
parameters.l2=0.3;%length from O_B2 to fore part of the 2st vessel
parameters.l=7;%rope length

parameters.Delta_l=2.5;%1.5%extended after part of the 1st vessel: larger ===>vessel 1 surge v >0

parameters.m1=44.6;
parameters.mx1=-2.76;
parameters.my1=-26.7;
parameters.M1=diag([parameters.m1+abs(parameters.mx1);parameters.m1+abs(parameters.my1)]);
parameters.dv_l1=[22.96;33.44];
parameters.Dv_l1=diag(parameters.dv_l1);
parameters.dv_q1=[6.28;62];
parameters.Dv_q1=diag(parameters.dv_q1);
% parameters.do_l1=50.38;%fitting from expe
% parameters.do_q1=228.19;%fitting from expe
parameters.do_l1=102;%fitting from expe by forcing 102
parameters.do_q1=15;%fitting from expe by forcing 102
parameters.J1=19.7;

% parameters.m2=14.5;
% parameters.mx2=-0.6;
% parameters.my2=-10;
% parameters.M2=diag([parameters.m2+abs(parameters.mx2);parameters.m2+abs(parameters.my2)]);
% parameters.dv_l2=[10;23];
% parameters.Dv_l2=diag(parameters.dv_l2);
% parameters.dv_q2=[2;21];%[2;7]
% parameters.Dv_q2=diag(parameters.dv_q2);
% % parameters.do_l2=26;
% % parameters.do_q2=156;
% parameters.do_l2=92;
% parameters.do_q2=12;
% parameters.J2=2.1432;

scaling=1;
parameters.m2=scaling.*14.5;
parameters.mx2=scaling.*-0.6;
parameters.my2=scaling.*-10;
parameters.M2=scaling.*diag([parameters.m2+abs(parameters.mx2);parameters.m2+abs(parameters.my2)]);
parameters.dv_l2=scaling.*[10;23];
parameters.Dv_l2=diag(parameters.dv_l2);
parameters.dv_q2=scaling.*[2;21];%[2;7]
parameters.Dv_q2=diag(parameters.dv_q2);
% parameters.do_l2=26;
% parameters.do_q2=156;
parameters.do_l2=scaling.*92;
parameters.do_q2=scaling.*12;
parameters.J2=scaling.*2.1432;

parameters.c_max=c_max;
parameters.c1_max=c1_max;
parameters.c2_max=c2_max;
parameters.o1=o1;
parameters.psi1=psi1;
parameters.o2=o2;
parameters.psi2=psi2;
parameters.v_max=v_max;
parameters.vareps=vareps;

% parameters.gamma_p=0.05;
% parameters.gamma_v=0.04;
% parameters.gamma_ell=0.01;
% parameters.gamma_o=0.1;
% parameters.k_p=0.5;
% parameters.k_v=0.5;
% parameters.k_ell=0.03;
% parameters.k_o=0.3;
% parameters.gamma_prime=0.5* parameters.k_v*inv(1 + 0.25*inv(parameters.k_p)*parameters.k_v*parameters.k_v);%0<... <k_v*inv(1 + 0.25*inv(k_p)*k_v*k_v)

scaling=1.2;%%1.8
parameters.gamma_p=scaling*0.05;
parameters.gamma_v=scaling*0.02;
parameters.gamma_ell=scaling*0.003;%0.01
parameters.gamma_o=scaling*0.1;
parameters.k_p=scaling*0.4;
parameters.k_v=scaling*0.8;
parameters.k_ell=scaling*0.009;%0.03
parameters.k_o=scaling*0.3;
parameters.gamma_prime=0.5* parameters.k_v*inv(1 + 0.25*inv(parameters.k_p)*parameters.k_v*parameters.k_v);%0<... <k_v*inv(1 + 0.25*inv(k_p)*k_v*k_v)


%%%%========================================================
e1=parameters.e1;
e2=parameters.e2;
l=parameters.l;
l1=parameters.l1;
l2=parameters.l2;
m1=parameters.m1;
mx1=parameters.mx1;
my1=parameters.my1;
M1=parameters.M1;
J1=parameters.J1;
M2=parameters.M2;
dv_q1=parameters.dv_q1;
Dv_q1=parameters.Dv_q1;
do_q1=parameters.do_q1;

Delta_l=parameters.Delta_l;
gamma_ell=parameters.gamma_ell;
gamma_p=parameters.gamma_p;
gamma_v=parameters.gamma_v;
k_p=parameters.k_p;
k_v=parameters.k_v;

%1.A)
if abs(Delta_l-(-l1-inv(l1)*inv(m1+abs(my1))*J1))>=eps
    disp('1.A): success')
else
    disp('1.A): failure')
end

%1.B)
bar_u=gamma_p*k_p + gamma_v*k_v;
tilde_u=min(eigs(M2))/max(eigs(M2))*lb_pd2 - bar_u;
if tilde_u>=eps
    disp('1.B): success')
else
    disp('1.B): failure')
end

parameters.bar_u=bar_u;
parameters.tilde_u=tilde_u;

dv_l2=parameters.dv_l2;
dv_q2=parameters.dv_q2;
do_l2=parameters.do_l2;
do_q2=parameters.do_q2;

%2.A)
tilde_m1=norm(M1)* (norm(M1)*norm(inv(M1))-1);
a=inv(l1)*norm(M1)*J1* (tilde_m1 + l1*norm(inv(M1))*norm(Dv_q1) + inv(J1)*norm(M1)*do_q1);
b=(m1+abs(my1))*norm(M1)* (tilde_m1 + l1*norm(inv(M1))*norm(Dv_q1) + inv(J1)*norm(M1)*do_q1);
c=0.5*sqrt(2)*(m1+abs(my1))^2*(e2'*dv_q1);
if Delta_l > -l1 + (2*a)/(sqrt(b^2+4*a*c)-b)
    disp('2.A): success')
else
    disp('2.A): failure')
end


% Initial conditions
ang20=pi/2;%heading angle of {B2} wrt {I}
R20=ang2rot(ang20);
q20=ang2q(ang20);
q20=q20./norm(q20);
p20=[45;0];
v20=[0;0];
o20=0;

angell0=pi/2;%heading angle of the rope wrt x_I
Rell0=ang2rot(angell0);
ell0=l.*Rell0*e1;%ell in {I}

ang10=pi/2+pi/10;%heading angle of {B1} wrt {I}
R10=ang2rot(ang10);
q10=ang2q(ang10);
q10=q10./norm(q10);
p10=ell0 + (l1+Delta_l).*R10*e1 + l2.*R20*e1 + p20;%%%
% v10=1.5.*null(ell0'*R10);%fulfil the second holomonic constraint when v20=o20=0=o10
v10=0.4.*null(ell0'*R10);%fulfil the second holomonic constraint when v20=o20=0=o10
o10=0;

%hybrid controller
x0 = [p10;v10;q10;o10; p20;v20;q20;o20];
%ref
[~,ref0]=ref(psi0,0,parameters);
% %check Lyas
% [~,~,~,~,Vcal0]=errs(x0,ref0,parameters);

% Simulation horizon
T = 1800;
J = 500;                                                       
                                                                        
% Solver tolerances
AbsTol = 1e-3;
RelTol = AbsTol*1e-1;
MaxStep = 1e-2;

input_dim=10;%ref dimension


% b_v1=[6;-6];
% b_v2=[2;-2];
% w=[b_v1;b_v2];%=w
b_v1=[0.8;-0.8];
b_v2=0.5.*b_v1;
w=[b_v1;b_v2];%=w

T_switch=0;



% %%%plot Omega[1]: fix zv_0, zell_0, zo_0, find zp_0
% N_samples = 100;
% 
% samples = zeros(N_samples,2);
% 
% count = 0;
% maxeig_M2=max(eigs(M2));
% mineig_M2=min(eigs(M2));
% 
% 
% [errs_0,T2_0,tension_0,norm_kappa2_0] = fcn_errs(x0,ref0,parameters);
% 
% % zp_0=errs_0(1:2);
% zv_0=errs_0(3:4);
% zell_0=errs_0(5);
% zo_0=errs_0(6);
% 
% while count < N_samples
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Generate candidate zp_0
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     zp_0 = 10*(2*rand(2,1)-1);
%     % Uniform in [-100,100]^2
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Compute bar_z
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     bar_z = fcn_bar_z( ...
%         zp_0,...
%         zv_0,...
%         zell_0,...
%         zo_0,...
%         parameters);
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Compute bar_v2
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     bar_v2 = ub_pd1 + bar_z;
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Compute upper bound on d_v
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     ub_dv2 = ...
%         max(dv_l2)*bar_v2 + ...
%         max(dv_q2)*bar_v2^2;
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Compute bar_omega2
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     bar_o2 = max( ...
%         (l2/do_l2)*( ...
%             maxeig_M2*(bar_u + ub_pd2) ...
%             + ub_dv2), ...
%         (l2/do_q2)*( ...
%             (maxeig_M2-mineig_M2) ...
%             * bar_v2));
% 
%     bar_o2 = max(bar_o2,norm(zo_0));
% 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % Evaluate Omega_1 condition
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%     lhs = ...
%         (maxeig_M2-mineig_M2)*bar_v2*bar_o2 ...
%         + ub_dv2;
% 
%     rhs = maxeig_M2*tilde_u;
% 
%     if lhs < rhs
% 
%         count = count + 1;
% 
%         samples(count,:) = zp_0';
% 
%     end
% 
% end
% 
% 
% figure;
% scatter(samples(:,1),samples(:,2),20,'filled');
% 
% xlabel('z_{p,0}(1)');
% ylabel('z_{p,0}(2)');
% title('100 samples in \Omega_1');
% 
% axis equal
% grid on











% sim('simu_23b.slx')
% save data_800s_ellipse_nominal